#ifndef OMP_VERIFYRESULT_H
#define OMP_VERIFYRESULT_H

#include <vector>

int verifyResult(std::string &fileName, std::vector<int> &BV);

#endif //OMP_VERIFYRESULT_H